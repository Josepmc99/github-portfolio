# CHRouting
-All inputs (locations, time windows, manual order prioirity, etc.) located in Inputs2 file
-All API code located in api_distance_matrix file
-All other data processing functions located in Functions2 file
-Increasing layers of complexity can be achieved by running the following files:
BasicCase2-->TimeWindowCase2-->TimeWindowAndOrderPriorityCase2-->IterativeCase2

